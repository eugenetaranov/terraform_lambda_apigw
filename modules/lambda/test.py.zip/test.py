#!/usr/bin/env python


def lambda_handler(event, context):
  print('hello 2')
